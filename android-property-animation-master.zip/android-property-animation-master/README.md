__This repo contains demo code for the following Tuts+ Android tutorial__:

## Android SDK: Creating a Simple Property Animation
http://code.tutsplus.com/tutorials/android-sdk-creating-a-simple-property-animation--mobile-15022

I'm adding the code here as an additional way for readers to use/ contribute to it.

The tutorial was written some time ago so the techniques in it may well be out of date - but I'm starting this repo with the source code as it was when written, so that anyone who read the tutorial then can see any subsequent changes clearly.

Feel free to use the code or to contribute to it - I might update it at some point but don't hold your breath!

_Please note: Although the code here started the same as the tutorial, I recreated the app in Eclipse prior to adding it to GitHub. For this reason some of the automatically generated files may appear differently to your own if you followed the tutorial steps in the past._
